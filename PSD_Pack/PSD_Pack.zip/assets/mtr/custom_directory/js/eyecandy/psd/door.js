importPackage(java.awt);
importPackage(java.awt.geom);

include(Resources.id("mtr:custom_directory/js/nteutil/src/time_tracker.js"));
include(Resources.id("mtr:custom_directory/js/nteutil/src/format_util.js"));
include(Resources.id("mtr:custom_directory/js/nteutil/src/mtr_util.js"));

const model_l = ModelManager.uploadVertArrays(ModelManager.loadRawModel(Resources.manager(), Resources.idr("placement/door_left.csv"), null));

const model_r = ModelManager.uploadVertArrays(ModelManager.loadRawModel(Resources.manager(), Resources.idr("placement/door_right.csv"), null));

const light_off = ModelManager.uploadVertArrays(ModelManager.loadRawModel(Resources.manager(), Resources.idr("placement/door_light_off.csv"), null));

const light_on = ModelManager.uploadVertArrays(ModelManager.loadRawModel(Resources.manager(), Resources.idr("placement/door_light_on.csv"), null));

function createBlock(ctx, state, blockEntity) {
    state.doorValue = 0;
    state.timeTracker = new TimeTracker();
    state.etaRateLimit = new RateLimit(1);
    state.etas = 0;
    state.closestPlatform = getPlatform(blockEntity);
}

function renderBlock(ctx, state, blockEntity) {
    state.timeTracker.tick();
    
    if(state.etaRateLimit.shouldUpdate()) {
        if(state.closestPlatform != null) {
            let schedules = MTRUtil.getETAForPlatform(state.closestPlatform.id);
            if(schedules.length > 0) {
                state.etas = schedules[0].arrivalMillis;
            } else {
                state.etas = 0;
            }
        }
    }
    
    if(state.closestPlatform != null) {
        let dwell = state.closestPlatform.dwellTime / 2;
        let eta = (state.etas - java.lang.System.currentTimeMillis()) / 1000;
        
        eta += 1;
        if(eta <= -0.5) {
            let remainingDwell = dwell - (-eta);
            let speed = state.timeTracker.delta() * 0.75;
            if(remainingDwell < 3) {
                state.doorValue = Math.max(0, state.doorValue - speed);
            } else {
                state.doorValue = Math.min(1, state.doorValue + speed);
            }
        } else {
            state.doorValue = 0;
        }
    }
    
    
    let mat = new Matrices();
    mat.pushPose();
    mat.translate(-state.doorValue, 0, 0);
    ctx.drawModel(model_l, mat);
    mat.popPose();
    
    
    mat.pushPose();
    mat.translate(1, 0, 0);
    mat.translate(state.doorValue, 0, 0);
    ctx.drawModel(model_r, mat);
    mat.popPose();
    
    mat.pushPose();
    ctx.drawModel(state.doorValue == 0 ? light_off : light_on, mat);
    mat.popPose();
}

function getPlatform(blockEntity) {
    if(targetPlat == "auto") {
        return MTRUtil.getClosePlatform(blockEntity.getWorldPos(), 5, 4, 4);
    } else {
        let platforms = MTRUtil.getClosePlatforms(blockEntity.getWorldPos(), 5, 4, 4);
        let remainingPlatforms = platforms.filter(e => e.name == targetPlat);
        return remainingPlatforms.length == 0 ? null : remainingPlatforms[0];
    }
}

function disposeBlock(ctx, state, blockEntity) {
}